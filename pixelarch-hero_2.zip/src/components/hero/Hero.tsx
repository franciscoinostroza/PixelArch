import { motion, useReducedMotion, type Variants } from 'framer-motion'
import HeroBackground from './HeroBackground'
import PixelButton from './PixelButton'

const EASE = [0.22, 0.9, 0.32, 1] as const

const container: Variants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.12, delayChildren: 0.1 },
  },
}

const item: Variants = {
  hidden: { opacity: 0, y: 18, filter: 'blur(6px)' },
  visible: {
    opacity: 1,
    y: 0,
    filter: 'blur(0px)',
    transition: { duration: 0.7, ease: EASE },
  },
}

export default function Hero() {
  const reduceMotion = useReducedMotion()

  return (
    <section className="relative flex h-[100svh] min-h-[560px] w-full items-center overflow-hidden bg-void">
      <HeroBackground />

      {/* ambient light — digital fog */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <motion.div
          className="absolute -left-24 top-[8%] h-[420px] w-[420px] rounded-full bg-violet/20 blur-[120px]"
          animate={reduceMotion ? undefined : { y: [0, 26, 0] }}
          transition={{ duration: 16, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute -right-24 top-[28%] h-[380px] w-[380px] rounded-full bg-cyan/15 blur-[130px]"
          animate={reduceMotion ? undefined : { y: [0, -22, 0] }}
          transition={{ duration: 14, repeat: Infinity, ease: 'easeInOut', delay: 1.5 }}
        />
        <motion.div
          className="absolute -bottom-24 left-[28%] h-[320px] w-[320px] rounded-full bg-magenta/10 blur-[120px]"
          animate={reduceMotion ? undefined : { y: [0, 18, 0] }}
          transition={{ duration: 18, repeat: Infinity, ease: 'easeInOut', delay: 0.6 }}
        />
      </div>

      {/* keeps the canvas from hard-cutting into the next section */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-void" />

      <motion.div
        variants={container}
        initial="hidden"
        animate="visible"
        className="relative z-10 mx-auto w-full max-w-3xl px-6 sm:px-10"
      >
        <motion.div
          variants={item}
          className="mb-6 inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 backdrop-blur-md"
        >
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan/70" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-cyan" />
          </span>
          <span className="font-pixel text-[9px] tracking-wide text-cyan">
            SOFTWARE + REDES
          </span>
        </motion.div>

        <motion.h1
          variants={item}
          className="font-display text-[2.4rem] font-semibold leading-[1.15] tracking-tight text-ink sm:text-[3.4rem] lg:text-[4rem]"
        >
          Construimos el software.
          <br />
          Diseñamos{' '}
          <span className="bg-gradient-to-r from-cyan via-violet to-magenta bg-clip-text text-transparent">
            la red que lo sostiene
          </span>
          .
        </motion.h1>

        <motion.p
          variants={item}
          className="mt-6 max-w-xl font-body text-base leading-relaxed text-muted sm:text-lg"
        >
          Desarrollo full-stack e ingeniería de redes en un mismo equipo. No solo
          programamos tu producto: pensamos dónde corre, cómo escala y qué pasa
          el día que algo falla.
        </motion.p>

        <motion.div
          variants={item}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <PixelButton href="#contacto" variant="primary">
            Hablemos de tu proyecto
          </PixelButton>
          <PixelButton href="#productos" variant="ghost">
            Ver productos
          </PixelButton>
        </motion.div>
      </motion.div>

      <motion.div
        className="absolute inset-x-0 bottom-8 flex justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.1, duration: 0.6 }}
      >
        <motion.span
          aria-hidden="true"
          className="flex h-9 w-6 items-start justify-center rounded-full border border-white/15 p-1.5"
          animate={reduceMotion ? undefined : { y: [0, 6, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
        >
          <span className="h-1.5 w-1 rounded-full bg-cyan" />
        </motion.span>
      </motion.div>
    </section>
  )
}
