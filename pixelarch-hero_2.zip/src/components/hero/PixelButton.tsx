import { motion } from 'framer-motion'
import type { ReactNode, MouseEventHandler } from 'react'

interface PixelButtonProps {
  children: ReactNode
  href?: string
  variant?: 'primary' | 'ghost'
  onClick?: MouseEventHandler
}

const EASE = [0.22, 0.9, 0.32, 1] as const

const BASE =
  'relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-lg px-7 py-3.5 font-body text-sm font-semibold'

function Sheen() {
  return (
    <motion.span
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent"
      initial={{ x: '-120%' }}
      whileHover={{ x: '120%' }}
      transition={{ duration: 0.7, ease: 'easeInOut' }}
    />
  )
}

export default function PixelButton({
  children,
  href,
  variant = 'primary',
  onClick,
}: PixelButtonProps) {
  const isPrimary = variant === 'primary'

  const className = isPrimary
    ? `${BASE} text-void bg-gradient-to-r from-cyan via-violet to-magenta`
    : `${BASE} text-ink bg-white/[0.03] border border-white/10 backdrop-blur-sm`

  const hover = isPrimary
    ? {
        scale: 1.03,
        y: -2,
        boxShadow: '0 12px 34px -8px rgba(139,107,255,0.55)',
      }
    : {
        scale: 1.03,
        y: -2,
        borderColor: 'rgba(53,224,255,0.5)',
      }

  const initialShadow = isPrimary
    ? { boxShadow: '0 0 0 1px rgba(255,255,255,0.06) inset' }
    : undefined

  if (href) {
    return (
      <motion.a
        href={href}
        onClick={onClick}
        className={className}
        style={initialShadow}
        whileHover={hover}
        whileTap={{ scale: 0.98, y: 0 }}
        transition={{ duration: 0.35, ease: EASE }}
      >
        {isPrimary && <Sheen />}
        <span className="relative z-10">{children}</span>
      </motion.a>
    )
  }

  return (
    <motion.button
      type="button"
      onClick={onClick}
      className={className}
      style={initialShadow}
      whileHover={hover}
      whileTap={{ scale: 0.98, y: 0 }}
      transition={{ duration: 0.35, ease: EASE }}
    >
      {isPrimary && <Sheen />}
      <span className="relative z-10">{children}</span>
    </motion.button>
  )
}
