import { useEffect, useRef } from 'react'

/**
 * HeroBackground
 * ---------------
 * A lightweight canvas particle field: three parallax depth layers of
 * 1–3px "pixel" dust, a handful of slow-fading light blocks, and a few
 * circuit-trace lines that pulse very softly. Everything is driven by a
 * single requestAnimationFrame loop and drawn with plain fillRect calls,
 * which is cheap enough to hold 60fps without reaching for WebGL.
 *
 * Reduced motion: renders one static frame and skips the loop entirely.
 * Visibility: the loop pauses while the tab is hidden.
 */

type ParticleKind = 'drift' | 'block'

interface Particle {
  layer: 0 | 1 | 2
  x: number
  y: number
  size: number
  baseAlpha: number
  color: string
  vy: number
  phase: number
  freq: number
  amp: number
  kind: ParticleKind
}

interface CircuitLine {
  x1: number
  y1: number
  x2: number
  y2: number
  phase: number
  freq: number
  color: string
}

const ACCENTS = ['#35e0ff', '#8b6bff', '#ff4fd8', '#3f7dff']
const DUST = 'rgba(244,244,246,1)'

const LAYER_CONFIG = [
  { speed: 2.2, sizeMin: 0.6, sizeMax: 1.2, alphaMin: 0.12, alphaMax: 0.35, parallax: 5 },
  { speed: 4.2, sizeMin: 0.9, sizeMax: 1.6, alphaMin: 0.2, alphaMax: 0.5, parallax: 11 },
  { speed: 7, sizeMin: 1.2, sizeMax: 2.2, alphaMin: 0.35, alphaMax: 0.75, parallax: 20 },
] as const

function buildParticles(width: number, height: number): Particle[] {
  const area = width * height
  const count = Math.max(70, Math.min(170, Math.round(area / 9000)))
  const particles: Particle[] = []

  for (let i = 0; i < count; i++) {
    const layer = (Math.floor(Math.random() * 3) as 0 | 1 | 2)
    const cfg = LAYER_CONFIG[layer]
    const isAccent = Math.random() < 0.12
    const isBlock = Math.random() < 0.15

    particles.push({
      layer,
      x: Math.random() * width,
      y: Math.random() * height,
      size: cfg.sizeMin + Math.random() * (cfg.sizeMax - cfg.sizeMin) * (isBlock ? 1.6 : 1),
      baseAlpha: cfg.alphaMin + Math.random() * (cfg.alphaMax - cfg.alphaMin),
      color: isAccent ? ACCENTS[Math.floor(Math.random() * ACCENTS.length)] : DUST,
      vy: isBlock ? 0 : -(cfg.speed / 60) * (0.4 + Math.random() * 0.8),
      phase: Math.random() * Math.PI * 2,
      freq: isBlock ? 0.15 + Math.random() * 0.2 : 0.5 + Math.random() * 0.8,
      amp: isBlock ? 0.9 : 0.35,
      kind: isBlock ? 'block' : 'drift',
    })
  }
  return particles
}

function buildCircuits(width: number, height: number): CircuitLine[] {
  const lines: CircuitLine[] = []
  const n = Math.max(3, Math.min(6, Math.round(width / 340)))
  for (let i = 0; i < n; i++) {
    const x1 = Math.random() * width
    const y1 = Math.random() * height
    const horizontal = Math.random() > 0.5
    const len = 40 + Math.random() * 90
    lines.push({
      x1,
      y1,
      x2: horizontal ? x1 + len : x1,
      y2: horizontal ? y1 : y1 + len,
      phase: Math.random() * Math.PI * 2,
      freq: 0.1 + Math.random() * 0.15,
      color: ACCENTS[Math.floor(Math.random() * ACCENTS.length)],
    })
  }
  return lines
}

export default function HeroBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const dpr = Math.min(window.devicePixelRatio || 1, 2)

    let width = 0
    let height = 0
    let particles: Particle[] = []
    let circuits: CircuitLine[] = []
    let rafId = 0
    let running = true
    let t = 0

    const pointer = { x: 0, y: 0, smoothX: 0, smoothY: 0 }

    function resize() {
      const parent = canvas!.parentElement
      width = parent ? parent.clientWidth : window.innerWidth
      height = parent ? parent.clientHeight : window.innerHeight
      canvas!.width = Math.round(width * dpr)
      canvas!.height = Math.round(height * dpr)
      canvas!.style.width = width + 'px'
      canvas!.style.height = height + 'px'
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0)
      particles = buildParticles(width, height)
      circuits = buildCircuits(width, height)
    }

    function onPointerMove(e: PointerEvent) {
      const cx = width / 2
      const cy = height / 2
      pointer.x = (e.clientX - cx) / cx
      pointer.y = (e.clientY - cy) / cy
    }

    function drawFrame() {
      ctx!.clearRect(0, 0, width, height)
      pointer.smoothX += (pointer.x - pointer.smoothX) * 0.04
      pointer.smoothY += (pointer.y - pointer.smoothY) * 0.04

      for (const p of particles) {
        const cfg = LAYER_CONFIG[p.layer]
        if (!reduceMotion) {
          p.y += p.vy
          if (p.y < -4) p.y = height + 4
        }
        const flicker = 1 + Math.sin(t * p.freq + p.phase) * p.amp
        const alpha = Math.max(0, Math.min(1, p.baseAlpha * flicker))
        const ox = pointer.smoothX * cfg.parallax
        const oy = pointer.smoothY * cfg.parallax * 0.6

        ctx!.globalAlpha = alpha
        ctx!.fillStyle = p.color
        ctx!.fillRect(Math.round(p.x + ox), Math.round(p.y + oy), p.size, p.size)
      }

      ctx!.lineWidth = 1
      for (const c of circuits) {
        const pulse = (Math.sin(t * c.freq + c.phase) + 1) / 2
        ctx!.globalAlpha = 0.06 + pulse * 0.16
        ctx!.strokeStyle = c.color
        ctx!.beginPath()
        ctx!.moveTo(c.x1, c.y1)
        ctx!.lineTo(c.x2, c.y2)
        ctx!.stroke()
      }
      ctx!.globalAlpha = 1
    }

    function loop() {
      if (!running) return
      t += 1 / 60
      drawFrame()
      rafId = requestAnimationFrame(loop)
    }

    resize()
    drawFrame()

    if (!reduceMotion) {
      rafId = requestAnimationFrame(loop)
      window.addEventListener('pointermove', onPointerMove, { passive: true })
    }

    const ro = new ResizeObserver(() => {
      resize()
      if (reduceMotion) drawFrame()
    })
    ro.observe(canvas.parentElement ?? canvas)

    function onVisibility() {
      if (document.hidden) {
        running = false
        cancelAnimationFrame(rafId)
      } else if (!reduceMotion) {
        running = true
        rafId = requestAnimationFrame(loop)
      }
    }
    document.addEventListener('visibilitychange', onVisibility)

    return () => {
      running = false
      cancelAnimationFrame(rafId)
      ro.disconnect()
      window.removeEventListener('pointermove', onPointerMove)
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="absolute inset-0 h-full w-full"
    />
  )
}
