import Hero from './components/hero/Hero'

// This file intentionally renders only the Hero, per the brief:
// "no cambies la estructura general de la página ni el branding".
// Drop <Hero /> (src/components/hero/*) straight into the existing
// site's page — everything below it stays exactly as it is today.
export default function App() {
  return (
    <main className="bg-void">
      <Hero />
    </main>
  )
}
