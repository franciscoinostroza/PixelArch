# PixelArch — Hero premium (rediseño)

Hero standalone en React + Vite + TypeScript + Tailwind v4 + Framer Motion.
Verificado: `tsc --noEmit`, `vite build` y `oxlint` pasan sin errores.

## Correr en local

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # build de producción en /dist
```

## Estructura

```
src/
  components/hero/
    Hero.tsx            composición principal (layout + motion)
    HeroBackground.tsx  canvas de partículas (el fondo animado)
    PixelButton.tsx      CTA reutilizable con glow + sheen
  index.css              tokens de diseño (@theme) + fuentes
  App.tsx                 solo renderiza <Hero /> — el resto de tu
                           landing no se toca
```

## Integrarlo en tu sitio real

1. Copiá la carpeta `src/components/hero/` completa a tu proyecto.
2. Copiá el bloque `@theme { ... }` de `src/index.css` a tu CSS global
   (o fusionalo con tus tokens actuales — los nombres son namespaced:
   `void`, `panel`, `ink`, `muted`, `dim`, `cyan`, `violet`, `magenta`,
   `neonblue`, y las tres familias `font-display/body/pixel`).
3. Agregá los `<link>` de Google Fonts de `index.html` a tu `<head>`.
4. Instalá `framer-motion` si todavía no lo tenés: `npm i framer-motion`.
5. Reemplazá tu `<Hero />` actual por `<Hero />` de acá. Todo lo demás
   de tu página (Productos, Proceso, Nosotros, Contacto) sigue igual.

## Decisiones de diseño (resumen — el detalle completo está en el chat)

- **Tipografía**: Pixelify Sans para título + tag (legible a diferencia
  de Press Start 2P), Inter para todo el texto de lectura, Press Start 2P
  reservado a un detalle mínimo (el tag "SOFTWARE + REDES").
- **Fondo**: Canvas 2D (no WebGL — no hace falta para ~150 partículas),
  tres capas de profundidad con parallax por mouse, partículas que
  titilan y "bloques" que aparecen/desaparecen, más unas líneas de
  circuito muy sutiles. Se pausa si la pestaña no está visible y
  respeta `prefers-reduced-motion`.
- **Motion**: entrada escalonada Título → Subtítulo → CTA con
  fade + slide + blur, blobs de luz ambiental flotando muy lento,
  botón con glow y barrido de brillo al hover.
